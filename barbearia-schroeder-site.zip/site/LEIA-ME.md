# Barbearia Schroeder — Guia de Publicação (Netlify, grátis)

## O que tem nesta pasta
- `index.html` — o site
- `images/logo.png` — sua logo
- `images/uploads/` — pasta onde vão as fotos que você subir pelo painel
- `data/gallery.json` — lista de fotos do portfólio (o site lê esse arquivo)
- `admin/` — o painel de administração (só você consegue entrar)

## Passo 1 — Colocar o código no GitHub
1. Crie uma conta grátis em https://github.com (se ainda não tiver)
2. Crie um repositório novo, ex: `barbearia-schroeder`
3. Suba todos os arquivos desta pasta pra esse repositório (dá pra arrastar e soltar direto no site do GitHub, em "Add file → Upload files")

## Passo 2 — Publicar no Netlify
1. Crie uma conta grátis em https://netlify.com (pode entrar com a conta do GitHub)
2. Clique em **Add new site → Import an existing project**
3. Escolha o repositório `barbearia-schroeder`
4. Deixe as configurações padrão (não precisa build command nem publish directory especial) e clique em **Deploy**
5. Em alguns segundos o site estará no ar num endereço tipo `nome-aleatorio.netlify.app`

## Passo 3 — Ativar o login do painel (só pra você)
1. No painel do Netlify, vá em **Site configuration → Identity → Enable Identity**
2. Em **Registration**, mude para **Invite only** (assim ninguém cria conta sozinho)
3. Ainda em Identity, vá em **Services → Git Gateway** e clique em **Enable Git Gateway**
4. Vá em **Identity → Invite users** e convide o seu próprio e-mail
5. Você vai receber um e-mail — clique no link, defina uma senha
6. Pronto: acesse `seusite.netlify.app/admin` e entre com seu e-mail e senha

Só quem você convidar pelo Identity consegue acessar o `/admin`. Ninguém mais cria conta sozinho.

## Passo 4 — Adicionar suas fotos
Depois de logado em `/admin`, clique em **Galeria (Trabalhos)** → **Fotos** → **Adicionar item** → escolha a imagem do computador. Ao salvar, o site atualiza sozinho em cerca de 1 minuto.

## Passo 5 — Usar o domínio barbeariaschroeder.com.br
1. Registre o domínio em https://registro.br (R$ 40/ano)
2. No Netlify, vá em **Domain management → Add a domain** e digite `barbeariaschroeder.com.br`
3. O Netlify vai te dar os dados de DNS — copie e cole eles no painel do Registro.br (em "Editar Zona DNS" ou "Servidores DNS")
4. Leva algumas horas para propagar, depois o domínio já aponta pro site

---
Qualquer dúvida em algum desses passos, é só chamar.
